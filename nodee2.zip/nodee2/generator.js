generator.prototype.generate = function()
{
    console.log('Entering - File: generator.js, Method: generate');
  
    var that = this;
  
    that.client.incr('jobId', function (err1, jobId){
        if (err1)
        {
            console.log('File: generator.js, Method: generate, client.incr error: ' + err1.message);
            throw err1;
        }
      
      
        that.client.lpush('jobQueue', jobId, function(err2, res){
            if (err2)
            {
                console.log('File: generator.js, Method: generate, client.lpush error: ' + err2.message);
                throw err2;
            }
            console.log('File: generator.js, Method: generate, jobId %d placed on queue', jobId);
            utils.notifyDispatcher(that.client, JSON.stringify({'type' : 'job', 'id' : jobId}));
        });
    });
  
    console.log('Exiting - File: generator.js, Method: generate');
}; 