var cluster = require('cluster');
var _ = require('lodash');
var http = require('http');
var workers = [];
var workerCount = 4;

if (cluster.isMaster) {
  for (var i = 0; i < workerCount; i++) {
    var worker = cluster.fork();

    worker.on('message', function(msg) {
      if (msg.task === 'sync') {
            syncPlayerList(msg.data);
      }
    });
  }
  workers.push[worker];

} else {
  var worker = new Worker();
  process.on('message', function(msg) {
    if (msg.task === 'sync') {
        worker.playerList = msg.data;
    }
  });
}

function syncPlayerList (playerList) {
    _.forEach(workers, function (worker) {
        worker.send({
            task: 'sync',
            data: playerList
        });
    });
};


// worker class
function Worker() {
    this.playerList = [];
}

Worker.prototype.sendSyncEvent = function () {
    process.send({
        task: 'sync',
        data: this.playerList
    })
};