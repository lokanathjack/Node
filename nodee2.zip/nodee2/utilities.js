var notifyScript = 'local jobQueueLen = redis.call(\'llen\', KEYS[1]) \
                    local workerQueueLen = redis.call(\'llen\', KEYS[2]) \
                    if (jobQueueLen > 0 and workerQueueLen > 0) then \
                        return redis.call(\'publish\', KEYS[3], ARGV[1]) \
                    else \
                        return -1 \
                    end';

utilities.notifyDispatcher = function(client, msg)
{
    console.log('Entering - File: utilities.js, Method: notifyDispatcher, msg: %s', msg);
    client.eval(notifyScript, 3, 'jobQueue', 'workerQueue', 'queueMessages', msg, function (err, res){
        if (err)
        {
            console.log('File: utilities.js, Method: notifyDispatcher, client.eval error: ' + err.message);
            throw err;
        }
      
        console.log('File: utilities.js, Method: notifyDispatcher, client eval res:' + res);
        if (res == 0)  //resend 1 second later if no Dispatcher received the message
        {
            setTimeout(function(){ utilities.notifyDispatcher(client, msg);}, 1000);
        }
    });
  
    console.log('Exiting - File: utilities.js, Method: notifyDispatcher, msg: %s', msg);
};