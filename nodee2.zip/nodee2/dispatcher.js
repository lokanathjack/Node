var dispatchScript = 'local jobQueueLen = redis.call(\'llen\', KEYS[1]) \
                      local workerQueueLen = redis.call(\'llen\', KEYS[2]) \
                      if (jobQueueLen > 0 and workerQueueLen > 0) then \
                        local job = redis.call(\'rpop\', KEYS[1]) \
                        local worker = redis.call(\'rpop\', KEYS[2]) \
                        return {job, worker} \
                      else \
                        return nil \
                      end';

function messageHandler(client, msg)
{
    console.log('Entering - File: dispatcher.js, Method: messageHandler');
    client.eval(dispatchScript, 2, 'jobQueue', 'workerQueue', function (err, res){
        if (err)
        {
            console.log('File: dispatcher.js, Method: messageHandler, redis eval error: ' + err.message);
            throw err;
        }
        if (res && res.length == 2) 
            notifyWorker(client, res[0], res[1]);
    });
    console.log('Exiting - File: dispatcher.js, Method: messageHandler');
}; 