var cluster = require('cluster');
var domain = require('domain');
var redis = require('redis');
var os = require('os');
//var logger = require('./logger');
//var timestamper = require('./timeStamper');
//var worker = require('./worker');
//var dispatcher = require('./dispatcher');
//var utilities = require('./utilities');
var properties = require('./properties');
var numProcesses = os.cpus().length;

if (cluster.isMaster)
{
  
    var client = redis.createClient(properties.redisServer.port, properties.redisServer.host);
    var multi = client.multi();
    multi.del('start');
    multi.del('jobId');
    multi.del('jobQueue');
    multi.del('workerQueue');
    multi.exec(function (err, res){
        if (err)
            throw err;
        cluster.fork({processType : 'dispatcher'});
        numProcesses--;
      
        do
        {
            cluster.fork({processType : 'worker'});
            numProcesses--;
        }
        while (numProcesses > 0);
        multi.quit();
        client.quit();
    });
  
 cluster.on('disconnect', function(worker) {  //process died
  console.log('File: main.js, Worker %d died', worker.process.pid);
 });
}
else
{
    console.log('File: main.js, ProcessType %s launched', process.env.processType);
    initDomain(process.env.processType);
}

worker.prototype.start = function()
{
    console.log('Entering - File: worker.js, Method: start, workerId:%s', this.workerId);
  
    var that = this;
  
    this.client.on('error', function (err){
        console.log('File: worker.js, Method: start, redis client error: ' + err.message);
        throw err;
    });
    this.subscriber.on('error', function (err){
        logger.error('File: worker.js, Method: start, subscriber client error: ' + err.message);
        throw err;
    });
  
    this.subscriber.subscribe(this.workerId);  //subscribe to a message channel specific to this worker
  
    this.subscriber.on('subscribe', function(channel, count){
        setWorkerAvailable(that.client, that.workerId);
    });
  
    this.subscriber.on('message', function(channel, msg){
        console.log('worker %s received job %s', that.workerId, msg);
        doWork(msg, function(){
                setWorkerAvailable(that.client, that.workerId);
                if (msg == properties.numJobs)
                {
                    that.client.get('start', function (err, res){
                        var duration = new Date().getTime() - res;
                        console.log('*****duration(ms): ' + duration);
                    });
                }
        });
    });
  
    console.log('Exiting - File: worker.js, Method: start, workerId:%s', this.workerId);
}; 

function setWorkerAvailable(client, workerId)
{
    console.log('Entering - File: worker.js, Method: setWorkerAvailable, workerId: %s', workerId);
    
    client.lpush('workerQueue', workerId, function (err, res){
        if (err)
        {
            console.log('File: worker.js, Method: setWorkerAvailable, client.lpush error: ' + err.message);
            throw err;
        }
        
        utils.notifyDispatcher(client, JSON.stringify({'type' : 'worker', 'id' : workerId}));
    });
    console.log('Exiting - File: worker.js, Method: setWorkerAvailable, workerId: %s', workerId);

};

function initDomain(processType)
{
    console.log('Entering - File: main.js, Method: initDomain, processType:%s, pid:%d', processType, process.pid);
    var d = domain.create();
    var client = redis.createClient(properties.redisServer.port, properties.redisServer.host);
    var subscriber = redis.createClient(properties.redisServer.port, properties.redisServer.host);
  
    d.on('error', function (err) {
        try
        {
            console.log('Crash: ' + err.message);
            var killtimer = setTimeout(function() {process.exit(1);}, 10000);
            killtimer.unref();
          
            client.quit();
            subscriber.quit();
            cluster.worker.disconnect();
        }
        catch (exc)
        {
            console.log( 'Error encountered during crash recovery: ' + exc.message);
        }
    });
  
    switch (processType)
    {
        case 'dispatcher':
            d.run(function() {
                new dispatcher(client, subscriber).start();
            });
            break;
    
        case 'worker':
            d.run(function() {
                new worker(os.hostname() + ':' + process.pid, client, subscriber).start();
            });
            break;
    }
  
    console.log('Exiting - File: main.js, Method: initDomain, processType:%s', processType);

};