var cluster = require('cluster');
var http = require('http');
var numReqs = 0;
var workers = [];
var numCPUs =[] ;
numCPUs = require('os').cpus().length;
if (cluster.isMaster) {
    //for (var i = 0; i < require('os').cpus.length; i++) {
      //  cluster.fork();
    //}
numCPUs.forEach(function(value){
  console.log(value);
});
    cluster.on('disconnect', function(worker) {
        cluster.fork();
		console.log("Success");
    });

    // When a new worker process is forked, attach the handler
    // This handles cases where new worker processes are forked
    // on disconnect/exit, as above.
    cluster.on('fork', function(worker) {
        worker.on('message', messageRelay);
    });

    var messageRelay = function(msg) {
        Object.keys(cluster.workers).forEach(function(id) {
            cluster.workers[id].send(msg);
        });
    };
}
else {
    process.on('message', messageHandler);

    var messageHandler = function messageHandler(msg) {
        // Worker received message--do something
		// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
// Load credentials and set region from JSON file
AWS.config.loadFromPath('./config.json');

// Create the DynamoDB service object
ddb = new AWS.DynamoDB();

var params = {
  TableName: 'TABLE',
  Key: {
    'KEY_NAME' : {N: '001'},
  },
  ProjectionExpression: 'ATTRIBUTE_NAME'
};

// Call DynamoDB to read the item from the table
ddb.getItem(params, function(err, data) {
  if (err) {
    console.log("Error", err);
  } else {
    console.log("Success", data.Item);
  }
});
    };
}