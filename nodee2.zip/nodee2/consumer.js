const express = require("express");
const bodyParser = require("body-parser");
const url = require('url');
const fs = require("fs");
const expressSession = require("express-session");
const expressHantweb2 = require("express-hantweb2");
const HttpStatus = require('http-status-codes');
const https = require('https');
const Promise = require("bluebird")
const axios  = require("axios");
const uuid = require('node-uuid');
const jwt = require('express-jwt');
const jsonwebtoken = require("jsonwebtoken");
const _ = require("lodash")
const AWS = require('aws-sdk');
const omitEmpty = require('omit-empty');
const HttpsAgent = require('agentkeepalive').HttpsAgent;
const keepaliveAgent = new HttpsAgent();

const StateEnum = require('../../util/StateEnum.es6')
const Response = require('../../util/Response.es6')
const NotificationType = require('../../util/NotificationType.es6')
const WorkItemDB = require('../db/workitem')

const config = require('../config');
const logger = config.LOGGER
const ldapLookup = config.ldapLookup
//Bearer Token
const BearerToken = require('../../util/BearerToken')(config.SERVICE_USER, config.SERVICE_PASS);

const EMAIL_SUBJECT_PREFIX = config.EMAIL_SUBJECT_PREFIX

const docClient = config.docClient

const WORK_ITEMS_TABLE = config.WORK_ITEMS_TABLE
const COMMENTS_TABLE = config.COMMENTS_TABLE
const STATE_INDEX = config.STATE_INDEX
const WEBHOOK_INDEX = config.WEBHOOK_INDEX
const DOMAIN_INDEX = config.DOMAIN_INDEX
const DOMAIN_STATE_INDEX = config.DOMAIN_STATE_INDEX
const NOTIFICATION_INDEX = config.NOTIFICATION_INDEX
const LOOKUP_KEY_INDEX = config.LOOKUP_KEY_INDEX

const TRUE = config.TRUE
const FALSE = config.false

const ATTRIBUTE_LOOKUP_MAP = {
  "user": "targetAudience",
  "group": "toGroup"
}

var publicKey = config.publicKey
var hostTokens = [];
const ALLOWABLE_CLOCK_SKEW_SECONDS = 30;

// ===== CONSUMER API ROUTER ==================================================
const consumerApiRouter = express.Router();

// Make sure JSON payloads are parsed
consumerApiRouter.use(bodyParser.json())

// Since the consumer API is going to be called from web applications
// that may have been served up by other servers we need to make sure
// that any response that we send back has the CORS headers installed.
consumerApiRouter.use(function (req, res, next) {
  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin',"*");
  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods',
    "GET, POST, OPTIONS, PUT, PATCH, DELETE");
  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers',
    "X-Requested-With,content-type,Authorization");
  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials',true);
  // Pass to next layer of middleware
  next('');
});

// Setup JWT verificiation of the Authorization header and put the credentials
// into the request object.  This is onl used for the Consumer API.
consumerApiRouter.use(jwt({
  secret: publicKey,
  credentialsRequired: false
}));

// Diagnostics logging
consumerApiRouter.all("/*",(req,res,next) => {
  logger.info("CONSUMER API HIT (" + req.method + ") FROM " +
    getUser(req) + " " + req.url);
  next();
});

// invoked from type ahead for employees
consumerApiRouter.get('/lookupEmployees',function(req,res) {
  ldapLookup.getAllEmployees(req.query.filter, function(err, results) {
      if (err) {
        logger.error('ERROR: ' +JSON.stringify(err));
        return;
      }
      else {
        res.status(HttpStatus.OK).send(results).end();      }
  });
});

consumerApiRouter.post('/actions',function(req,res) {

  if (isAuthenticated(req)) {
    var user = getUser(req)

    // check if its a bulk actions post
    if (Array.isArray(req.body)) {
      Promise.map(req.body, function(actionReq) {
            return actionReq.endUser ? processAction(actionReq.endUser, actionReq)
                                    : processAction(user, actionReq)
      })
      .then ((responses) => {
        res.status(HttpStatus.OK).send(JSON.stringify(responses)).end();
      })
    } else {
      processAction(user, req.body)
      .then (actionResponse => {
        if (actionResponse.code != HttpStatus.OK) {
          logger.error("Action on work item failed: " + actionResponse)
        }
        logger.info("Action on work item succeeded: " + actionResponse)
        res.status(actionResponse.code).send(actionResponse.response).end();
      });
    }
  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }

});

// NOTE: this is invoked by a link in email notification
// This would be used only for actions where where isInputAllowed and isInputRequired is false.
// Process action will performs relevant checks and prevents action, if invoked accidentally.
consumerApiRouter.get('/actions',function(req,res) {
  if (isAuthenticated(req)) {
    var user = getUser(req)
  
    var actionReq = req.query;
    // Get the item
    WorkItemDB.getItem(actionReq.id)
    .then (item => {
      if (!item) {
        logger.error("Request for action on unknown item: " + actionReq.id);
        return buildResponse(actionReq.id, HttpStatus.NOT_FOUND, Response.ITEM_NOT_FOUND);
      }

      const action = item.originatorData.actions.find(item => item.id == actionReq.action);
      if (!action) {
        logger.error(`Request for unrecognized action (${actionReq.action}) on item ${actionReq.id}`);
        return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Action not found");
      }
    
      processActionOnItem(user, actionReq, item)
      .then (actionResponse => {
        var responseBannerColor = "green"
        var responseHeader = "SUCCESS!"
        var responseText = "has been posted successfully!"
        var failureDetails = ""
        if (actionResponse.code != HttpStatus.OK) {
          logger.error("Action on work item failed: " + actionResponse)
          responseBannerColor = "red";
          responseHeader = "FAILED!"
          responseText = "failed."
          failureDetails = `
                        <br>
                        <span style="font-weight:600;color:${responseBannerColor};">
                          Reason:
                        </span>
                        <span style="font-weight: normal;">
                          ${actionResponse.response}
                        </span>`
        }

        var body = `<!DOCTYPE html>
          <html lang="en">
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <meta http-equiv="X-UA-Compatible" content="IE=edge" />
            </head>
            <body style="background-color:#eeeeee">

              <div style="border-top: 4px ${responseBannerColor} solid;">
                <div style="
                          padding-left:15px;
                          font-family:'Lao UI';
                          display:block;
                          color:#333;
                          background-color: #ffffff;
                          font-size:15px;
                          line-height:35px;
                         ">
                  <span style="font-weight:600;color:${responseBannerColor};">
                    ${responseHeader}
                  </span>
                  <div>
                    <span style="font-weight:600;color:#555;">
                      "${action.text}"
                    </span>
                    <span style="font-weight: normal;">
                      &nbsp;action request for 
                    </span>
                    <span style="font-weight:600;color:#555;">
                      ${item.domain}
                    </span>
                    <span style="font-weight: normal;">
                      &nbsp;work item of type 
                    </span>
                    <span style="font-weight:600;color:#555;">
                      &nbsp;${item.type}
                    </span>
                    <span style="font-weight: normal;">
                      &nbsp;${responseText}
                    </span>
                    ${failureDetails}
                  </div>
                </div>
              </div>
            </body>
          </html>
          `
        res.status(actionResponse.code).send(body).end();
      });
    });
  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});

consumerApiRouter.post('/blogs',function(req,res) {

  if (isAuthenticated(req)) {
    var user = getUser(req)

    if (!user) {
      res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
    }

    // Check for a legal request
    if (!req.body.id) {
      res.status(HttpStatus.BAD_REQUEST).send(Response.ID_MISSING).end();
    }

    var comment = buildCommentPayload("blog", req.body, user);

    // persist the comment the item
    persistComment(comment)
    .then(response => {
      logger.info("Comment added successfully: ", req.body.id)
      res.status(HttpStatus.OK).end();
    })
    .catch(reject => {
      logger.error("Error adding comment for item: ", req.body.id)
      res.status(HttpStatus.BAD_REQUEST).send("Error saving comment!").end();
    });
  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});

consumerApiRouter.post('/claims',function(req,res) {

  if (isAuthenticated(req)) {
    var user = getUser(req)

    // check if its a bulk actions post
    if (Array.isArray(req.body)) {

      Promise.map(req.body, function(claimReq) {
          return (claimReq.endUser  ? processClaim(claimReq.endUser, claimReq)
                            : processClaim(user, claimReq));
      })
      .then ((responses) => {
        res.status(HttpStatus.OK).send(JSON.stringify(responses)).end();
      })
    } else {
      processClaim(user, req.body)
      .then (claimResponse => {
            if (claimResponse.code != HttpStatus.OK) {
                logger.error("Claim on work item failed: " + claimResponse)
            }
            logger.info("Claim on work item succeeded: " + claimResponse)
            res.status(claimResponse.code).send(claimResponse.response).end();
      })

    }

  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }

});

// Request by the claimee of an item to release it and open it up for grabs by the group
consumerApiRouter.post('/releases',function(req,res) {

  if (isAuthenticated(req)) {
    var user = getUser(req)

    // check if its a bulk actions post
    if (Array.isArray(req.body)) {

      Promise.map(req.body, function(releaseReq) {
          return (releaseReq.endUser  ? processRelease(releaseReq.endUser, releaseReq)
                            : processRelease(user, releaseReq));
      })
      .then((response) => {
        res.status(HttpStatus.OK).send(JSON.stringify(responses)).end();
      })
    } else {
      processRelease(user, req.body)
      .then((releaseResponse) => {
        if (releaseResponse.code != HttpStatus.OK) {
            logger.error("Release on work item failed: " + releaseResponse)
        }
        logger.info("Release on work item succeeded: " + releaseResponse)
        res.status(releaseResponse.code).send(releaseResponse.response).end();
      });
    }

  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }

});

// Request by a consumer to snooze the item from showing up in list of sometime
consumerApiRouter.post('/snoozes',function(req,res) {

  if (isAuthenticated(req)) {
    var user = getUser(req)

    // check if its a bulk actions post
    if (Array.isArray(req.body)) {
        Promise.map(req.body, function(snoozeReq) {
          return (snoozeReq.endUser  ? processSnooze(snoozeReq.endUser, snoozeReq)
                            : processSnooze(user, snoozeReq));
        })
        .then((response) => {
          res.status(HttpStatus.OK).send(JSON.stringify(responses)).end();
        })
    } else {
      processSnooze(user, req.body)
      .then((snoozeResponse) => {
        if (snoozeResponse.code != HttpStatus.OK) {
            logger.error("Snooze on work item failed: " + snoozeResponse)
        }
        logger.info("Snooze on work item succeeded: " + snoozeResponse)
        res.status(snoozeResponse.code).send(snoozeResponse.response).end();
      });
    }
  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }

});

// TODO: Uncomment once we user based indexes in place
// As the domains and items are growing, doing a search without a domain
// is not suported for now, till we addm ore user specific indexes.
// No one is using it, commenting for now
// consumerApiRouter.get('/items',function(req,res) {
//   const user = getUser(req);

//   return getPendingItemsForUser(user)
//     .filter(f => !isSnoozed(user,f))
//     .map(f => renderForClient(user,f))
//     .then (result => {
//       res.status(HttpStatus.OK).send(result).end();
//     });
// });

consumerApiRouter.get('/item/:id/attachment/:fileName',function(req,res) {

  var itemId = req.params.id
  logger.info("REQUEST FOR WORKITEM ATTACHMENTMET - ID: " + itemId + " FILENAME: " + req.params.fileName);
  if (isAuthenticated(req)) {

    var user = getUser(req);
    WorkItemDB.getItem(itemId)
    .then((item) => {
      if (item.id) {
        // is the user authorized to view this attachment?
        if (JSON.stringify(item.targetAudience).toLowerCase().indexOf(user.toLowerCase()) == -1) {
          logger.error("Request for viewing an unauthorized attachment on item: " + itemId);
          res.status(HttpStatus.FORBIDDEN).send(Response.UNAUTHORIZED_USER).end();
          return;
        }

        // if user is valid, return the attachment
        var s3 = new AWS.S3();
        var params = {Bucket: config.ATTACHMENTS_BUCKET + itemId, Key: req.params.fileName};
        s3.getObject(params, function(err, data) {
          if (err || data == null) {
            logger.error("Error finding attachment file: ", err);
          } else {
            res.status(HttpStatus.OK);
            res.write(data.Body);
            res.end();
          }
        });
      } else {
        logger.error(`Request for attachment of an invalid item [${itemId}]`);
        res.status(HttpStatus.BAD_REQUEST).send(Response.ITEM_NOT_FOUND).end();
      }
    })
    .catch(err => {
      logger.error(`Error getting Item [${itemId}]`);
      res.status(HttpStatus.BAD_REQUEST).send(Response.ITEM_NOT_FOUND).end();
    })

  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});

consumerApiRouter.get('/item/:id',function (req,res) {
  if (isAuthenticated(req)) {
    const user = getUser(req);
    return WorkItemDB.getItem(req.params.id)
    .then((result) => {
       try {
        res.status(HttpStatus.OK).send(renderForClient(user,result)).end();
       } catch (ex) {
        logger.error("Item not found: " + req.params.id);
        res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end();
        return;
       }
     });
  } else {
      res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});

consumerApiRouter.post('/find',function(req,res) {

  if (isAuthenticated(req)) {
    var findRequest = omitEmpty(req.body);
    var countsOnly = (req.body.countsOnly == true || req.body.countsOnly == "true")
    var includeComments = (req.body.includeComments == true || req.body.includeComments == "true")
    var filters = _.omit(findRequest, ["countsOnly", "includeComments"])

    // check if required domain filter is passed in
    if (!filters.domain) {
      res.status(HttpStatus.BAD_REQUEST).send("Invalid request - domain filter is required").end();
      return;
    }

    // To support old search, route to find by domain if type or state is not included in the request
    if (!filters.state || !filters.type){
      
      var filterDomains = findRequest.domain;
      // incase state is not specified, search all states
      var filterStates = findRequest.state ? findRequest.state 
                            : [StateEnum.PENDING,
                               StateEnum.TIMEDOUT,
                               StateEnum.CANCELLED,
                               StateEnum.DONE]
                               
      return Promise.reduce(filterDomains, (domainItems, domain) => {
        Promise.reduce(filterStates, (stateItems, state) => {
          return findItemsByDomain(domain, state, 
                                buildFiltersMap(_.omit(filters, ["domain", "state"])));
        }, [])
        .map(f => renderForFind(f, includeComments))
        .then((result) => {
          try {
            res.status(HttpStatus.OK).send(result).end(); return;
          } catch (ex) {
            logger.error("Error finding items by domain: " + ex);
            res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end(); return;
          }
        })
      }, []);
    }

    buildLookupKeysForRequest(filters)
    .then(lookupKeys => {

      // as domain, state, type and cookie filters have been clubbed into lookup keys
      // clear them from the filters
      filters = _.omit(filters, ["domain", "state", "type"])

      if (countsOnly) {
        var counts = {};
        var filterRequests = [];
        _.reduce(filters, function(counts, filterValues, filterAttribute) {
            var filterRequest = {}
            filterRequest[filterAttribute] = filterValues
            filterRequests.push(findItems(lookupKeys, buildFiltersMap(filterRequest))
                            .then (items => {
                                return getFilterCounts(items, filterAttribute, filterValues)
                            })
                            .then(filterCounts => {
                              counts[filterAttribute] = filterCounts
                            })
                            .catch (reject => {
                              logger.error(`Error filtering on attribute ${filterAttribute} with values ${filterValues}: ${reject}`)
                            }))
            return counts;
        }, counts);

        Promise.all(filterRequests).then(function() {
          res.status(HttpStatus.OK).send(counts).end();
        });

      } else {
        console.log("looking for items: ", lookupKeys)
        return findItems(lookupKeys, buildFiltersMap(filters))
            .map(f => renderForFind(f, includeComments))
            .then((result) => {
               try {
                 res.status(HttpStatus.OK).send(result).end(); return;
               } catch (ex) {
                logger.error("Error finding items: " + ex);
                res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end(); return;
               }
        });
      }
    })
    .catch(err => {
      logger.error("Error finding items: " + err);
      res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end(); return;
    })
  } else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});

consumerApiRouter.post('/findByDomain',function(req,res) {

  if (isAuthenticated(req)) {
    var findRequest = omitEmpty(req.body);
    var countsOnly = (findRequest.countsOnly == true || findRequest.countsOnly == "true")
    var includeComments = (findRequest.includeComments == true || findRequest.includeComments == "true")

    // check if domain filter was passed in
    if (!findRequest.domain) {
      res.status(HttpStatus.BAD_REQUEST).send("Invalid request").end();
      return;
    }

    var filters = _.omit(findRequest, ["countsOnly", "includeComments", "domain", "state"])

    if (countsOnly) {
      var counts = {};
      var filterRequests = [];
      _.reduce(filters, function(counts, filterValues, filterAttribute) {
          var filterRequest = {}
          filterRequest[filterAttribute] = filterValues
          filterRequests.push(findItemsByDomain(findRequest.domain, findRequest.state, buildFiltersMap(filters))
                            .then (items => {
                                return getFilterCounts(items, filterAttribute, filterValues)
                            })
                            .then(filterCounts => {
                              counts[filterAttribute] = filterCounts
                            })
                            .catch (reject => {
                              logger.error(`Error filtering on attribute ${filterAttribute} with values ${filterValues}: ${reject}`)
                            }))
          return counts;
      }, counts);

       Promise.all(filterRequests).then(function() {
         res.status(HttpStatus.OK).send(counts).end();
       });

    } else {
      return findItemsByDomain(findRequest.domain, findRequest.state, buildFiltersMap(filters))
            .map(f => renderForFind(f, includeComments))
            .then((result) => {
               try {
                 res.status(HttpStatus.OK).send(result).end(); return;
               } catch (ex) {
                logger.error("Error finding items by domain: " + ex);
                res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end(); return;
               }
       });
    }
  }  else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});

consumerApiRouter.get('/notificationPendingItems',function(req,res) {

  const user = getUser(req);
  if (isAuthenticated(req)) {

    // Check to make sure domain is passed in - required
    // Type is optional
    if (!req.query.domain) {
      res.status(HttpStatus.BAD_REQUEST).send(Response.DOMAIN_MISSING).end();
    }

    var filters = {
      domain: req.query.domain
    }

    if (req.query.type) {
      filters.type = req.query.type
    }

    return findNotificationPendingItems(buildFiltersMap(filters))
          .then((result) => {
             try {
              logger.info("Found notification pending items: ", result.length);
               res.status(HttpStatus.OK).send(result).end(); return;
             } catch (err) {
              logger.error("Error finding notification pending items: " + err);
              res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end(); return;
             }
     });
  }  else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }
});


consumerApiRouter.post('/notificationSent',function(req,res) {

  if (isAuthenticated(req)) {

    // Check to make sure Item ID is passed in 
    if (!req.body.id) {
      res.status(HttpStatus.BAD_REQUEST).send(Response.ID_MISSING).end();
      return;
    }

    var itemId = req.body.id;

    // Get the item
    WorkItemDB.getItem(itemId)
    .then (item => {

      if (!item) {
        logger.error("Request for updating notification state on an unknown item: " + itemId);
        res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end(); return;
      }

      // update teh notificationPending state
      item.notificationPending = FALSE;

      persistItem(item, null)
      .then (() => {
        logger.info("Updated notification state for Item: " + itemId);
        res.status(HttpStatus.OK).send("OK").end(); 
        return;
      })
      .catch(err => {
        logger.error("Error updating notification state for Item: " + itemId);
        res.status(HttpStatus.INTERNAL_SERVER_ERROR).send("Error updating notification state for Item: " + itemId).end(); 
        return;
      });

    })
    .catch(err => {
        logger.error("Error looking up Item to update notification state: " + itemId);
        res.status(HttpStatus.INTERNAL_SERVER_ERROR).send("Error looking up Item to update notification state: " + itemId).end(); 
        return;
    });
  }  else {
    res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
    return;
  }
});

consumerApiRouter.get('/view/:id',function (req,res) {
  if (isAuthenticated(req)) {

    const user = getUser(req);
    WorkItemDB.getItem(req.params.id)
    .then(result => {
       try {
         if (!isRelevantToUser(user, result)) {
           res.status(HttpStatus.FORBIDDEN).send(Response.UNAUTHORIZED_USER).end();
         } else {
           res.status(HttpStatus.OK).send(renderForClient(user,result)).end();
         }
       } catch (ex) {
           res.status(HttpStatus.NOT_FOUND).send(Response.ITEM_NOT_FOUND).end();
           return;
       }
     });

  } else {
      res.status(HttpStatus.FORBIDDEN).send(Response.INVALID_USER).end();
  }

});

// ===== GENERAL APPLICATION CODE =============================================

// Start a polling timer to watch for items that are timed out
setInterval(() => {
 checkForTimeouts();
},1000);

//Start a polling timer to service webhooks that need to be fired
setInterval(() => {
  fireWebhooks();
},10000);

function sendReject(response) {
  return new Promise((resolve, reject) => {
          reject(response);
        });
}

function processAction(user, actionReq) {

  // Check for a legal request
  if (!actionReq.id) {
    return buildResponse("ID Not found!", HttpStatus.BAD_REQUEST, Response.ID_MISSING);
  }

  if (!actionReq.action) {
    return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Invalid request - action missing");
  }

  if (!user) {
    return buildResponse(actionReq.id, HttpStatus.FORBIDDEN, Response.INVALID_USER);
  }

  // Get the item
  return WorkItemDB.getItem(actionReq.id)
  .then (item => {
    if (!item) {
      logger.error("Request for action on unknown item: " + actionReq.id);
      return buildResponse(actionReq.id, HttpStatus.NOT_FOUND, Response.ITEM_NOT_FOUND);
    }

    return processActionOnItem(user, actionReq, item);
  });
}

function processActionOnItem(user, actionReq, item) {

  // Check for legal state
  if (item.state != StateEnum.PENDING) {
     logger.error(`Request for action in invalid state (${item.state}) on item ${actionReq.id}`);
     if (item.state == StateEnum.DONE)
       return buildResponse(actionReq.id, HttpStatus.CONFLICT, Response.ITEM_RESOLVED);
     else if (item.state == StateEnum.TIMEDOUT)
       return buildResponse(actionReq.id, HttpStatus.CONFLICT, Response.ITEM_TIMEDOUT);
     else
       return buildResponse(actionReq.id, HttpStatus.CONFLICT, Response.INVALID_STATE);
  }

  // Are we allowed to take action?
  if (JSON.stringify(item.eligibleUsers).toLowerCase().indexOf(user.toLowerCase()) == -1) {
   logger.error(`Request for unauthorized action on item ${actionReq.id} by user (${user}). Eligible users are: ${item.eligibleUsers}`) ;
   return buildResponse(actionReq.id, HttpStatus.FORBIDDEN, Response.UNAUTHORIZED_USER);
  }

  // Check for legal action
  const action = item.originatorData.actions.find(item => item.id == actionReq.action);
  if (!action) {
   logger.error(`Request for unrecognized action (${actionReq.action}) on item ${actionReq.id}`);
   return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Action not found");
  }

  // Check for input
  if (!action.isInputAllowed && actionReq.input) {
     logger.error("Request with input not allowed on item " + actionReq.id);
     return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Input not allowed");
  }
  if (action.isInputRequired && !actionReq.input) {
     logger.error("Input required on item " + actionReq.id);
     return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Input is required");
  }
  if (action.inputChoices && action.inputChoices.indexOf(actionReq.input) == -1) {
   logger.error("Input not valid on item " + actionReq.id);
   return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Input was invalid");
  }

  // Mark as resolved
  item.state = StateEnum.DONE;
  item.resolution = {};
  item.resolution.action = actionReq.action;
  // set action at item level too for facilitating querying on it
  item.action = actionReq.action
  item.resolution.resolvedAt = (new Date()).getTime()
  item.resolution.resolvedBy = user;

  if (actionReq.input) {
   item.resolution.input = actionReq.input;
  }

  // schedule action specific webhook if any
  if (action.webhookURL) {
   item.resolution.webhookPending = TRUE
   item.resolution.webhookAttempts = 0
  }

  // Schedule item level webhook for action update to originator
  // ONLY if its NOT a timeout only webhook
  if (item.originatorData.webhookURL &&
      !item.originatorData.timeoutOnlyWebhook == true) {
   item.webhookPending = TRUE;
   item.webhookAttempts = 0
  }

  // Record the event in the even log
  logAction(item.id, item.resolution.action, item.resolution.input,
           item.resolution.resolvedBy, item.resolution.resolvedAt);

  // lookup name of the action user and save in resolution - convinience info only
  return lookupUser(user)
  .then (userInfo => {
    if (userInfo) {
      item.resolution.resolvedByUsername = userInfo.name
    }
    return persistItem(item, null)
    .then (() => {
      logger.info("Resolved item " + item.id,item);
      return buildResponse(actionReq.id, HttpStatus.OK, 
        `Action [${action.text}] taken successfully on the item!`);
    });
  })
  .catch(err => {
    logger.error("User lookup failed: ", user);
    return buildResponse(actionReq.id, HttpStatus.BAD_REQUEST, "Action by invalid user: " + user);
  });
}

// Request by a consumer to claim an item assigned to the group
function processClaim(user, claimReq) {
  if (!user) {
    return buildResponse(claimReq.id, HttpStatus.FORBIDDEN, Response.INVALID_USER);
  }

  // Check for a legal request
  if (!claimReq.id) {
    return buildResponse(claimReq.id, HttpStatus.BAD_REQUEST, Response.ID_MISSING);
  }

  // Get the item
  return WorkItemDB.getItem(claimReq.id)
    .then(item => {
          if (!item) {
              logger.error("Request for claim on unknown item " + claimReq.id);
              return buildResponse(claimReq.id, HttpStatus.NOT_FOUND, Response.ITEM_NOT_FOUND);
          }

          // Check is item can be claimed - was it sent to a group?
          if (item.originatorData.toGroup == null || item.originatorData.toGroup.length < 1) {
            logger.error("Request for claim on item that cant be claimed: " + claimReq.id);
            return buildResponse(claimReq.id, HttpStatus.CONFLICT, "Item cannot be claimed");
          }

          // Check for legal state
          if (item.state != StateEnum.PENDING) {
            logger.error("Request for claim in invalid state on item " + claimReq.id);
            return buildResponse(claimReq.id, HttpStatus.CONFLICT, Response.INVALID_STATE);
          }

          // Are we allowed to claim?
          if (JSON.stringify(item.targetAudience).toLowerCase().indexOf(user.toLowerCase()) == -1) {
            logger.error("Request for claim an unauthorized item " + claimReq.id);
            return buildResponse(claimReq.id, HttpStatus.FORBIDDEN, Response.UNAUTHORIZED_USER);
          }

          // Has it already been claimed
          if (item.claimedBy != null && item.claimedBy.length != 0
                  && !claimReq.override && claimReq.override != true) {
            logger.error("Request for claim of an item that has already been claimed: " + claimReq.id);
            return buildResponse(claimReq.id, HttpStatus.CONFLICT, "Item already claimed");
          }

          // Narrow down the list
          item.eligibleUsers = [ user ];
          item.claimedBy = user
          item.claimedAt = (new Date()).getTime();

          // if there is comment, add it
          var comment = claimReq.comment ? buildCommentPayload("claim", claimReq, user)
                                          : null

          // lookup name of the action user and save in resolution - convinience info only
          return lookupUser(user)
          .then (userInfo => {
            if (userInfo) {
              item.claimedByUsername = userInfo.name
            }
            return persistItem(item, comment)
            .then(data => {
                logger.info("Item claimed successfully: ", claimReq.id)
                return buildResponse(claimReq.id, HttpStatus.OK, "");
            })
            .catch(reject => {
                return buildResponse(claimReq.id, HttpStatus.CONFLICT, "Error saving item!");
            });
          })
          .catch(err => {
            logger.error("User lookup failed: ", user);
            return buildResponse(claimReq.id, HttpStatus.BAD_REQUEST, "Claimed by invalid user: " + user);
          })
      })
}

function processRelease(user, releaseReq) {

  if (!user) {
    return buildResponse(releaseReq.id, HttpStatus.FORBIDDEN, Response.INVALID_USER);
  }

  // Check for a legal request
  if (!releaseReq.id) {
    return buildResponse(releaseReq.id, HttpStatus.BAD_REQUEST, Response.ID_MISSING);
  }

  // Get the item
  return WorkItemDB.getItem(releaseReq.id)
    .then(item => {
      if (!item) {
        logger.error("Request for release on unknown item " + releaseReq.id);
        return buildResponse(releaseReq.id, HttpStatus.NOT_FOUND, Response.ITEM_NOT_FOUND);
      }

      // Check is item can be released - was it sent to a group?
      if (item.originatorData.toGroup == null || item.originatorData.toGroup.length < 1) {
        logger.error("Request for release on item that cant be released: " + releaseReq.id);
        return buildResponse(releaseReq.id, HttpStatus.CONFLICT, "Item cannot be released");
      }

      // Check for legal state
      if (item.state != StateEnum.PENDING) {
        logger.error("Request for release in invalid state on item " + releaseReq.id);
        return buildResponse(releaseReq.id, HttpStatus.CONFLICT, Response.INVALID_STATE);
      }

      // has it been claimed - else cant release
      if (item.claimedBy == null || item.claimedBy.length == 0) {
        logger.error("Request for release of an item that hasn't been claimed: " + releaseReq.id);
        return buildResponse(releaseReq.id, HttpStatus.CONFLICT, "Item hasnt been claimed yet");
      }

      // Is this the user who has claimed it? else, cant release
      if (JSON.stringify(item.eligibleUsers).toLowerCase() != user.toLowerCase()) {
        logger.error("Request for release an unauthorized item " + releaseReq.id);
        return buildResponse(releaseReq.id, HttpStatus.FORBIDDEN, Response.UNAUTHORIZED_USER);
      }

      // Open up the item to all group members
      item.eligibleUsers = item.targetAudience;
      item.claimedBy = null
      item.claimedByUsername = null
      item.claimedAt = null

      // if there is comment, add it
      var comment = releaseReq.comment ? buildCommentPayload("release", releaseReq, user)
                                      : null
      return persistItem(item, comment)
      .then(data => {
          logger.info("Item released successfully: ", releaseReq.id)
          return buildResponse(releaseReq.id, HttpStatus.OK, "");
      })
      .catch(reject => {
          return buildResponse(releaseReq.id, HttpStatus.CONFLICT, "Error saving item!");
      });
  })
}

function processSnooze(user, snoozeReq) {
  if (!user) {
    return buildResponse(snoozeReq.id, HttpStatus.FORBIDDEN, Response.INVALID_USER);
  }

  // Check for a legal request
  if (!snoozeReq.id) {
    return buildResponse(snoozeReq.id, HttpStatus.BAD_REQUEST, Response.ID_MISSING);
  }

  // Get the item
  return WorkItemDB.getItem(snoozeReq.id)
    .then(item => {
      if (!item) {
        logger.error("Request for snooze on unknown item " + snoozeReq.id);
        return buildResponse(snoozeReq.id, HttpStatus.NOT_FOUND, Response.ITEM_NOT_FOUND);
      }

      // Check for legal state
      if (item.state != StateEnum.PENDING) {
        logger.error("Request for snooze in invalid state on item " + snoozeReq.id);
        return buildResponse(snoozeReq.id, HttpStatus.CONFLICT, Response.INVALID_STATE);
      }

      // Is this the user eligibleUsers to snooze it
      if (JSON.stringify(item.eligibleUsers).toLowerCase().indexOf(user.toLowerCase()) == -1) {
        logger.error("Request for snoozing an unauthorized item " + snoozeReq.id);
        return buildResponse(snoozeReq.id, HttpStatus.FORBIDDEN, Response.UNAUTHORIZED_USER);
      }

      var snoozeDurationInHrs = snoozeReq.durationInHrs;
      var snoozeDeadlineMs = Date.now() + (snoozeDurationInHrs * 60 * 60 * 1000)
      if (item.deadlineMs <= snoozeDeadlineMs) {
        logger.error("Request for snoozing an item past deadline: " + snoozeReq.id);
        return buildResponse(snoozeReq.id, HttpStatus.CONFLICT, "Snooze duration past deadline");
      }

      // Add the user to the snooze list
      if (!item.snoozingUsers)
        item.snoozingUsers = [];

      item.snoozingUsers.push(snoozeItemForUser(item, user, snoozeDeadlineMs));
      return persistItem(item, null)
      .then(data => {
          logger.info("Item snoozed successfully: ", snoozeReq.id)
          return buildResponse(snoozeReq.id, HttpStatus.OK, "");
      })
      .catch(reject => {
          return buildResponse(snoozeReq.id, HttpStatus.CONFLICT, "Error saving item!");
      });
  })
}

function lookupUser(user) {
  return new Promise((resolve, reject) => {
    ldapLookup.lookupUser(user, function(err, userInfo) {
      if (err) {
        logger.error(`User lookup for ${user} failed: ${err}`); reject(err);
      } else if (userInfo){
        resolve(userInfo);
      }
    });
  });
}

function buildCommentPayload(commentType, request, user) {
  return  {
    id: uuid.v1(),
    workItemId: request.id,
    commentType: commentType,
    commentedBy: user,
    commentedAt: (new Date()).getTime(),
    comment: request.comment
  }
}

function logAction(itemID, action, input, resolvedBy, resolvedAt) {
  return;
  // const event = {
  //   id: ++state.lastEventID,
  //   stamp: new Date(),
  //   itemID: itemID,
  //   action: action,
  //   resolvedAt: resolvedAt
  // };
  //
  // if (input) { event.input = input; }
  // if (resolvedBy) { event.resolvedBy = resolvedBy; }
  // state.actions.push(event);
}

// The function is expected to be called periodically to sweep through all
// of the pending items and look for any that have timed out.
function checkForTimeouts() {
  getTimedOutItems()
    .then((items) => {
        _.forEach(items, (item) => {
          // Change state
          item.state = StateEnum.TIMEDOUT;
          // Schedule webhooks
          if (item.webhookURL) {
            item.webhookPending = TRUE
            item.webhookAttempts = 0;
          }
          // Log the event
          logAction(item.id,"TIMEOUT");
          persistItem(item, null);
        });
    });
}

function fireWebhooks() {
  getWebhookPendingItems()
    .then((items) => {
        _.forEach(items, (item) => {
          // fire workitem level webhook if its pending and  attempts hasnt reached limit
          if (item.webhookPending && (item.webhookAttempts < config.MAX_WEBHOOK_ATTEMPTS)) {
            fireWebhook(item.originatorData.webhookURL, item.originatorData.webhookAuthorization,
                        item, function(err) {
                                if (err) {
                                  item.webhookAttempts = item.webhookAttempts + 1
                                  logger.info("Webhook Attempts: ", item.webhookAttempts)
                                } else {
                                  item.webhookPending = FALSE;
                                }
                                persistItem(item, null);
                              })
          }

          // fire action level webhook if its pending and  attempts hasnt reached limit
          if (item.resolution && item.resolution.webhookPending
                  && (item.resolution.webhookAttempts < config.MAX_WEBHOOK_ATTEMPTS)) {

            var action = item.originatorData.actions.find(f => f.id == item.resolution.action);
            fireWebhook(action.webhookURL, action.webhookAuthorization,
                        item, function(err) {
                                if (err) {
                                  item.resolution.webhookAttempts = item.resolution.webhookAttempts + 1
                                  logger.info("Webhook Attempts: ", item.resolution.webhookAttempts)
                                } else {
                                  item.resolution.webhookPending = FALSE;
                                }
                                persistItem(item, null);
                              })
          }
        });
    });
}

function fireWebhook(webhookURL, webhookAuthorization, item, callback) {

  const payload = buildWebhookPayload(item)
  const trustedCA = ['./keys/WMCRootCA1.pem', './keys/WMCGPCA1.pem']

  https.globalAgent.options.ca = []
  for (const ca of trustedCA) {
    https.globalAgent.options.ca.push(fs.readFileSync(ca));
  }

  const axiosConfig = {
    timeout: 2500,
    rejectUnauthorized: false,
    httpsAgent: https.globalAgent
  };

  var postRequest = function() {
    logger.info(`Firing webhook for Item (${item.id}): ${webhookURL} with token: ${axiosConfig.headers}`);
    // logger.info("Payload: " + JSON.stringify(payload))
    var setting = process.env.NODE_TLS_REJECT_UNAUTHORIZED
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
    axios.post(webhookURL, payload, axiosConfig)
      .then(function(res) {
        logger.info(`WEBHOOK SUCCEEDED (ID: ${item.id}, URL: ${webhookURL}, STATUS: ${res.status}`);
        process.env.NODE_TLS_REJECT_UNAUTHORIZED = setting;
        callback(null);
      })
      .catch(function(res) {
        logger.error(`WEBHOOK FAILED (ID: ${item.id}, URL: ${webhookURL}, STATUS: ${res.status}`);
        callback(res);
      });
  };

  if (webhookAuthorization) {
    axiosConfig.headers = {
      "Authorization": webhookAuthorization
    };
    postRequest();
  } else {
    var parsedURL = url.parse(webhookURL)
    getTokenForHost(parsedURL.hostname, (err, token) => {
      if (err) {
        callback(err, "Error getting token for host: ", parsedURL.hostname)
      }

      axiosConfig.headers = {
        "Authorization": "Bearer " + token
      };
      postRequest();
    });
  }
}

function buildLookupKeysForRequest(filters) {
  return new Promise((resolve, reject) => {
    var filterKeys = ["domain", "state", "type"];
    var lookupKeys = [""];
    resolve(_.reduce(filterKeys, (lookupKeys, filterKey) => {
              var updatedLookupKeys = lookupKeys;
              var filterValues = filters[filterKey];
              // new set of filter values, regenerate the keys
              if (filterValues) {
                updatedLookupKeys = [];
              }

              _.forEach(lookupKeys, (lookupKey, index) => {
                _.forEach(filterValues, (filterValue) => {
                  updatedLookupKeys.push(lookupKey.length > 0 ? lookupKey  + "|" + filterValue 
                                                    : filterValue)
                })
              });

              return updatedLookupKeys;
            }, lookupKeys));
  });
}

function getFilterCounts(items, filterAttribute, filterValues) {
  return new Promise((resolve, reject) => {
    resolve(_.reduce(filterValues, function(filterValueCounts, filterValue) {
              filterValueCounts[filterValue] = _.size(applyFilter(items, filterAttribute, filterValue));
              return filterValueCounts
            }, {}));
  });
}

function applyFilter(items, attribute, filter) {
  var attributeToLookup = ATTRIBUTE_LOOKUP_MAP[attribute] ?
                          ATTRIBUTE_LOOKUP_MAP[attribute] : attribute
  // TODO: fix it... this is ugly, ugly!!!!!
  return items.filter(f => {
      return (attributeToLookup != "targetAudience") ? _.includes(f[attributeToLookup], filter)
                                :_.includes(f[attributeToLookup], filter.toLowerCase())
  })
}

function buildFiltersMap(filters) {
  return _.reduce(filters, function(filtersMap, value, attribute) {
        var attributeToLookup = ATTRIBUTE_LOOKUP_MAP[attribute] ?
                                ATTRIBUTE_LOOKUP_MAP[attribute] : attribute
        filtersMap[attributeToLookup] = value
        return filtersMap
  }, {});
}

function applyUserFilter(items, userFilter) {
  return _.filter(items, function(item) {
      return isRelevantToAnyUser(userFilter, item)
  });
}

//find comments for an item based on id
function getItemComments(workItemId) {
  var params = {
      TableName : COMMENTS_TABLE,
      KeyConditions: {
          "workItemId": {
              ComparisonOperator: "EQ",
              AttributeValueList: [workItemId]
          }
      }
  };

  return new Promise((resolve, reject) => {
      docClient.query(params, (err, data) => {
        if (err) {
          reject(err)
        } else {
          data.Items ? resolve(data.Items) : resolve(data)
        }
      });
  });
}

// TODO: Uncomment in the parent method is implemented /items
//Get pending items for a user
// TODO: update to use lookupKeys
// function getPendingItemsForUser(user) {
//   var userPendingItemsFilters = {
//     "user": [user],
//     "state": [StateEnum.PENDING]
//   }

//   return new Promise((resolve, reject) => {
//     findItems(buildFiltersMap(userPendingItemsFilters))
//           .then((result) => {
//              try {
//                resolve(result);
//              } catch (err) {
//               logger.error(`Error getting pending items for the user(${user}): ${err}`);
//               reject(err)
//              }
//      });
//   });

// }

//Get timed out items
function getTimedOutItems() {
  var params = {
      TableName : WORK_ITEMS_TABLE,
      IndexName: STATE_INDEX,
      KeyConditions: {
          "state": {
              ComparisonOperator: "EQ",
              AttributeValueList: [StateEnum.PENDING]
          },
          "deadlineMs": {
              ComparisonOperator: "LT",
              AttributeValueList: [Date.now()]
          }
      }
  };

  return new Promise((resolve, reject) => {
    docClient.query(params, (err, data) => {
      if (err) {
        reject(err)
      } else {
        if (data.Items.length != 0) {
          // load details of the items
          var itemIds = _.slice(_.map(data.Items, function(item) {
            return _.pick(item, ['id'])
          }), 0, 99);
          var batchGetParams = {
                RequestItems: {
                  "WorkItems": {
                    Keys: itemIds
                  }
                }
              };

          docClient.batchGet(batchGetParams, function(err, data) {
            if (err) {
              reject(err);
            } else {
              resolve(data.Responses.WorkItems);
            }
          });
        } else {
          resolve(data.Items)
        }
      }
    });
  });
}

//Get webhook pending items
function getWebhookPendingItems() {
  var params = {
      TableName : WORK_ITEMS_TABLE,
      IndexName: WEBHOOK_INDEX,
      KeyConditions: {
          "webhookPending": {
              ComparisonOperator: "EQ",
              AttributeValueList: [TRUE]
          },
          "webhookAttempts": {
              ComparisonOperator: "LT",
              AttributeValueList: [10]
          }
      }
  };

  return new Promise((resolve, reject) => {
      docClient.query(params, (err, data) => {
        if (err) {
          reject(err)
        } else {
          resolve(data.Items)
        }
      });
  });
}

function findItems(lookupKeys, filters) {

  var params = {
    TableName : WORK_ITEMS_TABLE,
    IndexName : LOOKUP_KEY_INDEX
  };

  // Include condition experssions only if more filters are present
  if (_.keys(filters).length != 0) {
    var filterExpression = ""
    var expressionAttributeNames = {}
    var expressionAttributeValues = {}

    filterExpression = _.reduce(filters, function(filterExpression, filterValue, filterAttribute) {

      var filterCondition = ""
      // User filter unfortunately requires custom handling as it could be many to many with target audience
      if (filterAttribute == "targetAudience" && filterValue.length != 0) {
        filterCondition = _.reduce(filterValue, function(usersFilterCondition, user) {
                expressionAttributeValues[":"+ user + "Filter"] = user.toLowerCase()
                return usersFilterCondition.length == 0 ? "contains(targetAudience, :" + user + "Filter)"
                        : usersFilterCondition + " OR " + "contains(targetAudience, :" + user + "Filter)"
            }, "");

      } else {
        filterCondition = "contains(:" + filterAttribute + "Filter, #" + filterAttribute + "1)"
        expressionAttributeNames["#" + filterAttribute + "1"] = filterAttribute
        expressionAttributeValues[":" + filterAttribute + "Filter"] = filterValue
      }

      return filterExpression.length == 0 ? filterCondition : filterExpression + " AND " + filterCondition
    }, filterExpression);

    // add filter expression only if present
    if (_.keys(filterExpression).length != 0) {
      params.FilterExpression = filterExpression
    }

    // add expression attribute names only if present
    if (_.keys(expressionAttributeNames).length != 0) {
      params.ExpressionAttributeNames = expressionAttributeNames
      params.ExpressionAttributeValues = expressionAttributeValues
    }
  }

  var queryExecute = function(lookupKey, callback) {
    
    var items = []
    var keyConditions = { 
                          "lookupKey": {
                            "ComparisonOperator":"EQ",
                            "AttributeValueList": {"S": lookupKey}
                          }
                        }

    params.KeyConditions = keyConditions

    docClient.query(params, function(err, result) {
      if (err) {
        logger.error(`Error finding items - Params( ${params}) Error (${err})`)
        callback(err)
      }
      else {
        logger.info(`received items for ${lookupKey}: ${result.Items.length}`)
        items = items.concat(result.Items);
        if (result.LastEvaluatedKey) {
          params.ExclusiveStartKey = result.LastEvaluatedKey
          queryExecute(lookupKey, callback);
        } else {
          callback(null, items);
        }
      }
    });
  }

  var resultset = [];
  var lookupPromises = _.map(lookupKeys, (lookupKey, index) => {
                          return  new Promise((resolve, reject) => {
                                      queryExecute(lookupKey, (err, itemsForLookupKey) => {
                                        if (err) {
                                          reject(err);
                                        } else {
                                          if (itemsForLookupKey.length > 0) {
                                            resultset = _.concat(resultset, itemsForLookupKey);
                                          }
                                          resolve(resultset);
                                        }
                                      })
                                  });
                            });

  return new Promise((resolve, reject) => {
    Promise.all(lookupPromises)
    .then(() => {
      resolve(resultset);
    })
    .catch(err => {
      reject(err);
    })
  });

}

function findItemsByDomain(domain, state, filters ) {

  var params = {
    TableName : WORK_ITEMS_TABLE,
    IndexName : DOMAIN_INDEX
  };

  var filterExpression = ""
  var expressionAttributeNames = {}
  var expressionAttributeValues = {}

  var keyConditionExpression = "#domain1 = :domainFilter"
  expressionAttributeNames["#domain1"] = "domain";
  expressionAttributeValues[":domainFilter"] = domain;

  // If state filter is included, use DomainStateIndex instead
  if (state != null) {
    params.IndexName = DOMAIN_STATE_INDEX
    keyConditionExpression += " and #state1 = :stateFilter";
    expressionAttributeNames["#state1"] = "state";
    expressionAttributeValues[":stateFilter"] = state;
  }

  // Include condition experssions only if more filters are present
  if (_.keys(filters).length != 0) {
    filterExpression = _.reduce(filters, function(filterExpression, filterValue, filterAttribute) {

      var filterCondition = ""
      // User filter unfortunately requires custom handling as it could be many to many with target audience
      if (filterAttribute == "targetAudience" && filterValue.length != 0) {
        filterCondition = _.reduce(filterValue, function(usersFilterCondition, user) {
                expressionAttributeValues[":"+ user + "Filter"] = user.toLowerCase()
                return usersFilterCondition.length == 0 ? "contains(targetAudience, :" + user + "Filter)"
                        : usersFilterCondition + " OR " + "contains(targetAudience, :" + user + "Filter)"
            }, "");

      } else {
        filterCondition = "contains(:" + filterAttribute + "Filter, #" + filterAttribute + "1)"
        expressionAttributeNames["#" + filterAttribute + "1"] = filterAttribute
        expressionAttributeValues[":" + filterAttribute + "Filter"] = filterValue
      }

      return filterExpression.length == 0 ? filterCondition : filterExpression + " AND " + filterCondition
    }, filterExpression);

    // add filter expression only if present
    if (_.keys(filterExpression).length != 0) {
      params.FilterExpression = filterExpression
    }
  }

  params.KeyConditionExpression = keyConditionExpression,
  params.ExpressionAttributeNames = expressionAttributeNames
  params.ExpressionAttributeValues = expressionAttributeValues

  var items = []
  var queryExecute = function(callback) {
    docClient.query(params, function(err, result) {
      if (err) {
        logger.error(`Error finding items - Params( ${params}) Error (${err})`)
        callback(err)
      }
      else {
        logger.info("received items: ", result.Items.length)
        items = items.concat(result.Items);
        if (result.LastEvaluatedKey) {
          params.ExclusiveStartKey = result.LastEvaluatedKey
          queryExecute(callback);
        } else {
          callback(null, items);
        }
      }
    });
  }

  return new Promise((resolve, reject) => {
    return queryExecute((err, items) => {
      if (err) {
        reject(err);
      } else {
        resolve(items)
      }
    });
  });
}

function findNotificationPendingItems(filters) {

  var params = {
    TableName : WORK_ITEMS_TABLE,
    IndexName : NOTIFICATION_INDEX,
    KeyConditions: {
        "notificationPending": {
            ComparisonOperator: "EQ",
            AttributeValueList: [TRUE]
        }
    }
  };

  var filterExpression = ""
  var expressionAttributeNames = {}
  var expressionAttributeValues = {}

  filterExpression = _.reduce(filters, function(filterExpression, filterValue, filterAttribute) {
    var filterCondition = "contains(:" + filterAttribute + "Filter, #" + filterAttribute + "1)"
    expressionAttributeNames["#" + filterAttribute + "1"] = filterAttribute
    expressionAttributeValues[":" + filterAttribute + "Filter"] = filterValue
    return filterExpression.length == 0 ? filterCondition : filterExpression + " AND " + filterCondition
  }, filterExpression);

  // add filters and expression names, values only if present
  if (_.keys(filterExpression).length != 0) {
    params.FilterExpression = filterExpression
    params.ExpressionAttributeNames = expressionAttributeNames
    params.ExpressionAttributeValues = expressionAttributeValues
  }

  var items = []
  var queryExecute = function(callback) {
    docClient.query(params, function(err, result) {
      if (err) {
        logger.error(`Error finding notification pending items (${params}) Error (${err})`)
        callback(err)
      }
      else {
        items = items.concat(result.Items);
        if (result.LastEvaluatedKey) {
          params.ExclusiveStartKey = result.LastEvaluatedKey
          queryExecute(callback);
        } else {
          callback(null, items);
        }
      }
    });
  }

  return new Promise((resolve, reject) => {
    return queryExecute((err, items) => {
      if (err) {
        reject(err);
      } else {
        resolve(items)
      }
    });
  });
}

function persistComment(comment) {
  return new Promise(function (resolve, reject){
    var params = {
        TableName: "WorkItemComments",
        Item: omitEmpty(comment)
    };

    docClient.put(params, function(err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data)
      }
    });
  });
}

function persistItem(item, comment) {
  return new Promise(function (resolve, reject){

    // set metadata attributes at work item level for querying support
    item.domain = item.originatorData.domain
    item.urgency = item.originatorData.urgency
    item.type = item.originatorData.type
    item.to = item.originatorData.to
    item.toGroup = item.originatorData.toGroup

    var params = {
                    "RequestItems": {
                      "WorkItems" : [
                        {
                          "PutRequest": {
                            "Item": omitEmpty(item)
                          }
                        }
                      ]
                    }
                  }

    // if comment, include in batch write
    if (comment) {
      params.RequestItems.WorkItemComments = [
                            {
                              "PutRequest": {
                                "Item": omitEmpty(comment)
                              }
                            }
                          ]
    }

    docClient.batchWrite(params, function(err, data) {
      if (err) {
        reject(err);
      } else {
        resolve(data)
      }
    });
  });
}

function persistItems(items) {
  return Promise.map(items, (item) => {
    // set metadata attributes at work item level for querying support
    item.domain = item.originatorData.domain
    item.urgency = item.originatorData.urgency
    item.type = item.originatorData.type
    item.to = item.originatorData.to
    item.toGroup = item.originatorData.toGroup

    return omitEmpty(item);
  })
  .then (itemsToPersist => {
    return new Promise(function (resolve, reject){
      var putRequests = _.map(itemsToPersist, (item) => {
        return {
          "PutRequest": {
            "Item": item
          }
        }
      });

      var params = {
                      "RequestItems": {
                        "WorkItems" : putRequests
                      }
                    }

      return docClient.batchWrite(params, function(err, data) {
        if (err) {
          reject(err);
        } else {
          resolve(data)
        }
      });
    })
  })
}

function buildResponse(id, responseCode, response) {
  return new Promise((resolve, reject) => {
    var actionRes = {
                      "id" : id,
                      "code": responseCode,
                      "response": response
                    }

    resolve(actionRes);
  });
}

// snooze item for user for certain hours
function snoozeItemForUser(item, user, snoozeDeadlineMs) {
  var snoozeItem = {
                      "user": user,
                      "snoozeDeadlineMs": snoozeDeadlineMs
                    }
  item.snoozingUsers.push(snoozeItem)
}

// Is this item snoozed by the user, and still below snoozeDeadlineMs
function isSnoozed(user, item) {
  if (item.snoozingUsers) {
    var snoozeUser = item.snoozingUsers.find(f => (f != null) && (f.user.toLowerCase() == user.toLowerCase()));
    //    logger.info("is snoozed: ", (snoozeUser && snoozeUser.snoozeDeadlineMs > Date.now()))
    return (snoozeUser && snoozeUser.snoozeDeadlineMs > Date.now())
  }

  return false;
}

function isRelevantToUser(user,item) {
  if (user) {
    return (JSON.stringify(item.targetAudience).toLowerCase().indexOf(user.toLowerCase()) >= 0);
  }
  return false
}

function isRelevantToAnyUser(users, item) {
  return _.some(users, function(user) {
    return (isRelevantToUser(user, item) && !isSnoozed(user,item))
  });
}

// This function puts the item into the format that can be shown to the
// consumer.
function renderForClient(user,item) {

  // Get everything that was sent originally
  var result = Object.assign({},item.originatorData);
  result.id = item.id;
  result.currentUser = user

  // If the item is pending someone other than the caller than modify the
  // rendered state.
  if (item.state == StateEnum.PENDING) {
      if (JSON.stringify(item.eligibleUsers).toLowerCase().indexOf(user.toLowerCase()) == -1) {
        result.state = "Pending Action (By someone else)";
      } else {
        result.state = StateEnum.PENDING;
      }
  } else {
    result.state = item.state;
  }

  result.createdAt = new Date(item.createdAt);
  result.eligibleUsers = item.eligibleUsers;

  // if the item has been claimed, include claimedBy user info
  if (item.claimedBy && item.claimedBy != null) {
    result.claimedBy = item.claimedBy
    result.claimedByUsername = item.claimedByUsername
    result.claimedAt = new Date(item.claimedAt)
  }

  if (item.deadlineMs) {
    var ms = item.deadlineMs - Date.now();
    result.secondsToDeadline = Math.round(ms / 1000);
  }

  // Bring across the resolution
  if (item.resolution) {
    result.resolution = item.resolution;
  }
  return result;
}

function renderForFind(item, includeComments) {

  // Get everything that was sent originally
  var result = Object.assign({},item.originatorData);
  result.id = item.id;
  result.state = item.state;
  result.createdBy = item.createdBy;
  result.createdAt = new Date(item.createdAt);

  // if the item has been claimed, include claimedBy user info
  if (item.claimedBy && item.claimedBy != null) {
    result.claimedBy = item.claimedBy
    result.claimedByUsername = item.claimedByUsername
    result.claimedAt = new Date(item.claimedAt)
  }

  // include deadlineMs only if initial deadline was set in the initial request
  if (item.originatorData.deadline) {
    var ms = item.deadlineMs - Date.now();
    result.secondsToDeadline = Math.round(ms / 1000);
  }

  // Bring across the resolution
  if (item.resolution) {
    result.resolution = item.resolution;
    result.resolution.resolvedAt = new Date(item.resolution.resolvedAt)
  }

  // include comments if requested
  if (includeComments) {
    return getItemComments(item.id)
          .then (comments => {
            _.map(comments, (comment) => {
              comment.commentedAt = new Date(comment.commentedAt)
              return comment;
            })
            result.comments = comments
            return result
          });
  } else {
    return result;
  }
}

function isAuthenticated(req) {
  return getUser(req) != null
}

// This function pulls the user ID out of the request structure. 
// Supports the following:
  // - if some middleware stack loaded this structure using a verified JWT token
  // - end user explicitly pass in endUser attribute in the request 
  //    (this is only supported if the service was authenticated via service account first)
  // = request was redirected to hantweb2 prior to getting her, in which case the express-hantweb2 
  // middleware has set the jwtClaims on the session.
function getUser(req) {
  if (req.user) {
    if (req.body.endUser) {
      return req.body.endUser;
    } else if (req.query.endUser) {
      return req.query.endUser;
    } else {
      return req.user.id;
    }
  } else if (req.session.jwtClaims) {
      return req.session.jwtClaims.sub;
  } else {
    return null;
  }
}

/*
Builds a payload that will be posted to the webhook target URL
for the action taken notification
*/
function buildWebhookPayload(workItem) {

  var notificationType = workItem.state == StateEnum.TIMEDOUT ?
                            NotificationType.WORK_TIMEOUT : NotificationType.WORK_ACTION

  // Get everything that was sent originally
  var workItemDetails = Object.assign({},workItem.originatorData);

  var payload = {}
  payload.id = workItem.id
  payload.notificationType = notificationType
  payload.workItemDetails = workItemDetails

  if (workItem.state == StateEnum.TIMEDOUT) {
    payload.action = StateEnum.TIMEDOUT
  }

  if (workItem.state == StateEnum.DONE) {
    addActionDetailsToPayload(payload, workItem);
  }

  if (workItem.attachments) {
    payload.attachments = workItem.attachments
  }
  
  return payload
}

function getTokenForHost(targetHost, callback) {

  var p = new Promise((resolve, reject) => {
    var hostEntry = hostTokens.find(entry => entry.host == targetHost)
    var index = hostTokens.indexOf(hostEntry)
    if (hostEntry) {
      resolve(hostEntry);
    } else {
      reject("Host entry not found for: "+ targetHost);
    }
  })
  .then(hostEntry => {
    try {
      const jwtClaims = parseToken(targetHost, hostEntry.token);
      if (isJWTTimeValid(jwtClaims)) {
        logger.info("Cached token is valid for host: ", targetHost)
        callback(null, hostEntry.token)
      }
    } catch(err) {
      // remove invalid token
      var index = hostTokens.indexOf(hostEntry)
      if (index > -1) {
        hostTokens.splice(index, 1);
      }
      reject("Token expired for target host: "+ targetHost);
    }
  })
  .catch(err => {
    logger.error(`Error getting cached token for host[${targetHost}]: ${err}`);
    logger.info("Requesting Bearer Token from Hantweb2 for host: ", targetHost);
    BearerToken.getBearerToken(targetHost, (serviceToken) => {
      var e = new Promise((resolve, reject) => {
        var newEntry = hostTokens.find(entry => entry.host == targetHost)
        if (!newEntry) {
          logger.info("Pushing token: ", targetHost + ": " + serviceToken)
          hostTokens.push({ "host": targetHost, "token": serviceToken});
        };
        resolve(serviceToken);
      })
      .then(serviceToken => {
        callback(null, serviceToken)
      })
    });
  });
}

function parseToken(expectedAudience, token) {
  // Decode the claims inside of the JWT token and validate them.
  const jwtClaims = jsonwebtoken.verify(token, config.PUBLIC_KEY,
    {
      audience: expectedAudience,
      issuer: config.EXPECTED_ISSUER,
      // NOTE: This started to be a problem on 3/21/2016
      ignoreNotBefore: true
    });
  return jwtClaims;
}

function isJWTTimeValid(jwtClaims) {
  // Determine the expected audience (hostname) in the assertion.
  var currentStamp = Math.floor(Date.now() / 1000);
  // Validate the claims
  if (currentStamp > jwtClaims.exp + ALLOWABLE_CLOCK_SKEW_SECONDS ||
    currentStamp < jwtClaims.nbf - ALLOWABLE_CLOCK_SKEW_SECONDS) {
    return false;
  }
  return true;
}

function addActionDetailsToPayload(payload, workItem){
  if (workItem.resolution.resolvedBy) {
    payload.resolvedBy = workItem.resolution.resolvedBy;
  }

  if (workItem.resolution.resolvedByUsername) {
    payload.resolvedByUsername = workItem.resolution.resolvedByUsername;
  }

  payload.action = workItem.resolution.action;
  payload.resolvedAt = new Date(workItem.resolution.resolvedAt);
  if (workItem.resolution.input) {
    payload.input = workItem.resolution.input;
  }
}

module.exports = consumerApiRouter
