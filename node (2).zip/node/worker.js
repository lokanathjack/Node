worker.prototype.start = function()
{
    console.log('Entering - File: worker.js, Method: start, workerId:%s', this.workerId);
  
    var that = this;
  
    this.client.on('error', function (err){
        console.log('File: worker.js, Method: start, redis client error: ' + err.message);
        throw err;
    });
    this.subscriber.on('error', function (err){
        logger.error('File: worker.js, Method: start, subscriber client error: ' + err.message);
        throw err;
    });
  
    this.subscriber.subscribe(this.workerId);  //subscribe to a message channel specific to this worker
  
    this.subscriber.on('subscribe', function(channel, count){
        setWorkerAvailable(that.client, that.workerId);
    });
  
    this.subscriber.on('message', function(channel, msg){
        console.log('worker %s received job %s', that.workerId, msg);
        doWork(msg, function(){
                setWorkerAvailable(that.client, that.workerId);
                if (msg == properties.numJobs)
                {
                    that.client.get('start', function (err, res){
                        var duration = new Date().getTime() - res;
                        console.log('*****duration(ms): ' + duration);
                    });
                }
        });
    });
  
    console.log('Exiting - File: worker.js, Method: start, workerId:%s', this.workerId);
}; 

function setWorkerAvailable(client, workerId)
{
    console.log('Entering - File: worker.js, Method: setWorkerAvailable, workerId: %s', workerId);
    
    client.lpush('workerQueue', workerId, function (err, res){
        if (err)
        {
            console.log('File: worker.js, Method: setWorkerAvailable, client.lpush error: ' + err.message);
            throw err;
        }
        
        utils.notifyDispatcher(client, JSON.stringify({'type' : 'worker', 'id' : workerId}));
    });
    console.log('Exiting - File: worker.js, Method: setWorkerAvailable, workerId: %s', workerId);

};